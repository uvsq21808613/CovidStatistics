
public enum VaccineType {
	PFIZER,MODERNA;
}
